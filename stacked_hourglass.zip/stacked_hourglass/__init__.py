from stacked_hourglass.model import hg1, hg2, hg8
from stacked_hourglass.predictor import HumanPosePredictor
